In this module, we will create visualizations using the developer survey data.
The visualizations will highlight the distribution of data, relationships between data, the composition of data, and comparison of data.
