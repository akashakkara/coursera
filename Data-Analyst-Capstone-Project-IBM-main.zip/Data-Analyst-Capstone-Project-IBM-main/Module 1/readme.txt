Data Collection is the first step in solving any analysis problem and can be collected in many formats and from many sources.
In the first module of the Capstone, we will collect data by scraping the internet and using web APIs.
