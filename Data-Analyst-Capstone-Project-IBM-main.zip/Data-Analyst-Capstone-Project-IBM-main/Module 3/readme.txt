In this module, we begin working with the cleaned dataset from the previous module.
We will now begin to analyze the dataset to find the distribution of data, presence of outliers and the correlation between different columns.
