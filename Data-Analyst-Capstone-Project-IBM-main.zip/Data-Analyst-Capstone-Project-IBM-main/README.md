# Data-Analyst-Capstone-Project-IBM
IBM Data Analyst Professional Capstone project

Analysis Dashboard Link: [:link:](https://eu-de.dataplatform.cloud.ibm.com/dashboards/1b000c35-d301-4475-a59c-89c32e463130/view/513cdd3e03ec69ec4cb0eee407ca250e74662d59b7bbd103d5807b490e687297f36113c4c87d480fd3420c64f1bd1a0bcc)

Project Presentaion Link: [:link:](https://drive.google.com/file/d/1Ni0AdFz1-576X5W9E7ZzRSr31YhOAYtf/view?usp=sharing)

In this project, assuming myself as the Data Analyst for the company, I undertook the tasks of collecting data from multiple sources, performing exploratory data analysis, data wrangling and preparation, statistical analysis and mining the data, creating charts and plots to visualize data, and building an interactive dashboard using IBM Cognos Analytics.

Key requirements of analysis are identifying skills requirements for future, top programming languages, database skills in demand and IDEs in demand

At the end of project,I prepared a presentation of my data analysis report, with an executive summary for the various stakeholders in the organization including Human Resource and IT Head.
