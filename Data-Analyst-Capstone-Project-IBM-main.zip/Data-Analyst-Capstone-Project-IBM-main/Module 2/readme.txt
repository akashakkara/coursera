In this module, we will be focusing on the cleaning of your dataset with various techniques. 
With these techniques we will be identifying duplicate rows, finding missing values, and normalizing the dat
